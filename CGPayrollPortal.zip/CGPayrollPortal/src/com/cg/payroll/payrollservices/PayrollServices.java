package com.cg.payroll.payrollservices;

import java.util.List;
import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public interface PayrollServices {
	int acceptAssociatedetails(Associate associate);
	
	int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException;
	
	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException;
	
	List<Associate> getAllAssociatesDetails();
}
