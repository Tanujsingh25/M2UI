package com.cg.payroll.controllers;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.payrollservices.PayrollServices;
import com.cg.payroll.payrollservices.PayrollServicesImpl;

import oracle.net.aso.s;
@WebServlet("/calculateSalary")
public class CalculateSalary extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private  PayrollServices payrollServices = new PayrollServicesImpl();
	Salary salary;
    public CalculateSalary() {
        super();
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int associateId = Integer.parseInt(request.getParameter("associateId"));	
		RequestDispatcher dispatcher = null;		
			dispatcher = request.getRequestDispatcher("displaySalary.jsp");
			try {
				payrollServices.calculateNetSalary(associateId);
				salary= payrollServices.getAssociateDetails(associateId).getSalary();
			} catch (AssociateDetailsNotFoundException e) {
				e.printStackTrace();
			}
			request.setAttribute("salary", salary);
			dispatcher.forward(request, response);
	}

}
