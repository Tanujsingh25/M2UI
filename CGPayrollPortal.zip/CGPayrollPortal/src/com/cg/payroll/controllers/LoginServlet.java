package com.cg.payroll.controllers;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.payrollservices.PayrollServices;
import com.cg.payroll.payrollservices.PayrollServicesImpl;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private  PayrollServices payrollServices = new PayrollServicesImpl();
	public LoginServlet() {
		super();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String emailId = request.getParameter("email");
		String password = request.getParameter("password");
		String cpassword = request.getParameter("cpassword");
		String department = request.getParameter("department");
		String designation = request.getParameter("designation");
		String  pancard = request.getParameter("pancard");
		int yearlyInvestmentUnder80C = Integer.parseInt(request.getParameter("yearlyInvestment"));
		int basicPay = Integer.parseInt(request.getParameter("basicSalary"));
		String bankName = request.getParameter("bankName");
		int accountNo = Integer.parseInt(request.getParameter("accountNo"));
		String ifsc = request.getParameter("ifsc");
		Salary salary = new Salary(basicPay, 1000, 1000);
		BankDetails bankDetails = new BankDetails(accountNo, ifsc, bankName);
		Associate associate = new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, salary,bankDetails );
		RequestDispatcher dispatcher = null;
		if(password.equals(cpassword)) {
			payrollServices.acceptAssociatedetails(associate);
				dispatcher = request.getRequestDispatcher("registerSuccessPage.jsp");
				request.setAttribute("associate", associate);
				dispatcher.forward(request, response);
		}
		else {
			dispatcher = request.getRequestDispatcher("registrationPage.jsp");
			request.setAttribute("error", "Password does not match with confirm password.");
			dispatcher.forward(request, response);
		}
	}
}
