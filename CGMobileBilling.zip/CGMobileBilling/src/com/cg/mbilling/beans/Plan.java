package com.cg.mbilling.beans;

public class Plan {
	private int planId,monthlyRental,freeLocalCalls,freeLocalSms,freeStdSms,freeInternetDataUsageUnits;
	private float localCallRate,stdCallRate,localSmsRate,stdSmsRate,internetDataUsageRate;
	private String planName,planCircle;
	public Plan() {
		super();
	}

	public Plan(int planId, int monthlyRental, String planName, String planCircle) {
		super();
		this.planId = planId;
		this.monthlyRental = monthlyRental;
		this.planName = planName;
		this.planCircle = planCircle;
	}

	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public int getMonthlyRental() {
		return monthlyRental;
	}
	public void setMonthlyRental(int monthlyRental) {
		this.monthlyRental = monthlyRental;
	}
	public int getFreeLocalCalls() {
		return freeLocalCalls;
	}
	public void setFreeLocalCalls(int freeLocalCalls) {
		this.freeLocalCalls = freeLocalCalls;
	}
	public int getFreeLocalSms() {
		return freeLocalSms;
	}
	public void setFreeLocalSms(int freeLocalSms) {
		this.freeLocalSms = freeLocalSms;
	}
	public int getFreeStdSms() {
		return freeStdSms;
	}
	public void setFreeStdSms(int freeStdSms) {
		this.freeStdSms = freeStdSms;
	}
	public int getFreeInternetDataUsageUnits() {
		return freeInternetDataUsageUnits;
	}
	public void setFreeInternetDataUsageUnits(int freeInternetDataUsageUnits) {
		this.freeInternetDataUsageUnits = freeInternetDataUsageUnits;
	}
	public float getLocalCallRate() {
		return localCallRate;
	}
	public void setLocalCallRate(float localCallRate) {
		this.localCallRate = localCallRate;
	}
	public float getStdCallRate() {
		return stdCallRate;
	}
	public void setStdCallRate(float stdCallRate) {
		this.stdCallRate = stdCallRate;
	}
	public float getLocalSmsRate() {
		return localSmsRate;
	}
	public void setLocalSmsRate(float localSmsRate) {
		this.localSmsRate = localSmsRate;
	}
	public float getStdSmsRate() {
		return stdSmsRate;
	}
	public void setStdSmsRate(float stdSmsRate) {
		this.stdSmsRate = stdSmsRate;
	}
	public float getInternetDataUsageRate() {
		return internetDataUsageRate;
	}
	public void setInternetDataUsageRate(float internetDataUsageRate) {
		this.internetDataUsageRate = internetDataUsageRate;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getPlanCircle() {
		return planCircle;
	}
	public void setPlanCircle(String planCircle) {
		this.planCircle = planCircle;
	}
	
}
