package com.cg.mbilling.beans;

public class PostPaidAccount {
	private String mobileNo;
	private Bill[] bills;

	public PostPaidAccount() {
		super();
	}

	public PostPaidAccount(String mobileNo, Bill[] bills) {
		super();
		this.mobileNo = mobileNo;
		this.bills = bills;
	}


	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Bill[] getBills() {
		return bills;
	}

	public void setBills(Bill[] bills) {
		this.bills = bills;
	}
	
}
