package com.cg.mbilling.beans;

public class Bill {
	private int billID,noOfLocalSMS,noOfStdSMS,noOfLocalCalls,noOfStdCalls,internetDataUsage;
	private int sGST,cGST,billAmount,totalBillAmount,LocalSMSAmount,StdSMSAmount;
	private String internetDataUsageUnits,billMonth;
	private Address address;
	private Plan plan;
	public Bill() {
		super();
	}
	
	public Bill(int billID, int totalBillAmount, String billMonth, Address address, Plan plan) {
		super();
		this.billID = billID;
		this.totalBillAmount = totalBillAmount;
		this.billMonth = billMonth;
		this.address = address;
		this.plan = plan;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Plan getPlan() {
		return plan;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}

	public int getBillID() {
		return billID;
	}

	public void setBillID(int billID) {
		this.billID = billID;
	}

	public int getNoOfLocalSMS() {
		return noOfLocalSMS;
	}

	public void setNoOfLocalSMS(int noOfLocalSMS) {
		this.noOfLocalSMS = noOfLocalSMS;
	}

	public int getNoOfStdSMS() {
		return noOfStdSMS;
	}

	public void setNoOfStdSMS(int noOfStdSMS) {
		this.noOfStdSMS = noOfStdSMS;
	}

	public int getNoOfLocalCalls() {
		return noOfLocalCalls;
	}

	public void setNoOfLocalCalls(int noOfLocalCalls) {
		this.noOfLocalCalls = noOfLocalCalls;
	}

	public int getNoOfStdCalls() {
		return noOfStdCalls;
	}

	public void setNoOfStdCalls(int noOfStdCalls) {
		this.noOfStdCalls = noOfStdCalls;
	}

	public int getInternetDataUsage() {
		return internetDataUsage;
	}

	public void setInternetDataUsage(int internetDataUsage) {
		this.internetDataUsage = internetDataUsage;
	}

	public int getsGST() {
		return sGST;
	}

	public void setsGST(int sGST) {
		this.sGST = sGST;
	}

	public int getcGST() {
		return cGST;
	}

	public void setcGST(int cGST) {
		this.cGST = cGST;
	}

	public int getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}

	public int getTotalBillAmount() {
		return totalBillAmount;
	}

	public void setTotalBillAmount(int totalBillAmount) {
		this.totalBillAmount = totalBillAmount;
	}

	public int getLocalSMSAmount() {
		return LocalSMSAmount;
	}

	public void setLocalSMSAmount(int localSMSAmount) {
		LocalSMSAmount = localSMSAmount;
	}

	public int getStdSMSAmount() {
		return StdSMSAmount;
	}

	public void setStdSMSAmount(int stdSMSAmount) {
		StdSMSAmount = stdSMSAmount;
	}

	public String getInternetDataUsageUnits() {
		return internetDataUsageUnits;
	}

	public void setInternetDataUsageUnits(String internetDataUsageUnits) {
		this.internetDataUsageUnits = internetDataUsageUnits;
	}

	public String getBillMonth() {
		return billMonth;
	}

	public void setBillMonth(String billMonth) {
		this.billMonth = billMonth;
	}
	
	
}
