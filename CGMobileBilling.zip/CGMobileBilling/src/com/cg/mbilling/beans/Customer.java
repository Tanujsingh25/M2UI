package com.cg.mbilling.beans;

public class Customer {
	private int customerID;
	private String firstName,lastName,emailId,adharNo,pancardNo,dateOfBirth;
	private PostPaidAccount[] postPaidAccounts;
	
	public Customer() {	}

	public Customer(int customerID, String firstName, String lastName, String emailId, String adharNo, String pancardNo,
			String dateOfBirth, PostPaidAccount[] postPaidAccounts) {
		super();
		this.customerID = customerID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.adharNo = adharNo;
		this.pancardNo = pancardNo;
		this.dateOfBirth = dateOfBirth;
		this.postPaidAccounts = postPaidAccounts;
	}

	public PostPaidAccount[] getPostPaidAccounts() {
		return postPaidAccounts;
	}

	public void setPostPaidAccounts(PostPaidAccount[] postPaidAccounts) {
		this.postPaidAccounts = postPaidAccounts;
	}

	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAdharNo() {
		return adharNo;
	}

	public void setAdharNo(String adharNo) {
		this.adharNo = adharNo;
	}

	public String getPancardNo() {
		return pancardNo;
	}

	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public static void main(String[] args) {

		
	}

}
