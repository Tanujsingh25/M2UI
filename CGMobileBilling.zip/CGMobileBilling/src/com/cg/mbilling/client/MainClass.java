package com.cg.mbilling.client;
import com.cg.mbilling.beans.*;
public class MainClass {

	public static void main(String[] args) {
		Address[] addresses = new Address[] {
				new Address("delhi", "delhi", "India", 201009),
				new Address("Ghaziabad", "U.P", "India", 201007),
				new Address("Pune", "Maharashtra", "India", 201008)
				};
		Plan[] plans = new Plan[] {
				new Plan(101, 1000, "jadu Pack", "GZB"),
				new Plan(102, 250, "chota Pack", "delhi"),
				new Plan(103, 349, "jio jee bhar k", "Noida")
		}; 
		Bill[] bill1 = new Bill[] {
				new Bill(111, 1500, "October", addresses[0],plans[0] ),
				new Bill(112, 2000, "December", addresses[1], plans[1])
		};
		Bill[] bill2 = new Bill[] {
				new Bill(113, 1200, "Janaury", addresses[2], plans[2])
		};
		PostPaidAccount [] postPaidAccounts = new PostPaidAccount[] {
				new PostPaidAccount("9911016184",bill1),
				new PostPaidAccount("999999999",bill2)
		};
		Customer customer = new Customer(125, "tanuj", "kumar"," abc@1243.com", "11322qe", "1231esar3", "25/12/1996", postPaidAccounts);
		System.out.println(customer);
	}

}
